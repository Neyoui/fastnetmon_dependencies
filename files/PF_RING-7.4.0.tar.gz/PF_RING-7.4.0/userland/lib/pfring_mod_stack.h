/*
 *
 * (C) 2005-2018 - ntop.org
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesses General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 *
 */

#ifndef _PFRING_MOD_STACK_H_
#define _PFRING_MOD_STACK_H_

int pfring_mod_stack_open(pfring *ring);

#endif /* _PFRING_MOD_STACK_H_ */
