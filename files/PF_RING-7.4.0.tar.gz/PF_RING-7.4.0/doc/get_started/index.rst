Get Started
===========

.. toctree::
    :maxdepth: 2
    :numbered:

    git_installation
    packages_installation
