
User's Guide available at [www.ntop.org/guides/pf_ring](http://www.ntop.org/guides/pf_ring/)

API Documentation available at [www.ntop.org/pfring_api](http://www.ntop.org/pfring_api/files.html)
